<?php
session_start();
require 'db_connect.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the POST data
$gender = $_POST['gender'];
$age = $_POST['age'];
$weight = $_POST['weight'];
$height = $_POST['height'];
$bmi = $_POST['bmi'];
$classification = $_POST['classification'];

// Insert data into the database
$sql = "INSERT INTO nutrition_data (gender, age, weight, height, bmi, classification) VALUES ('$gender', '$age', '$weight', '$height', '$bmi', '$classification')";
if ($conn->query($sql) === TRUE) {
    echo json_encode(['status' => 'success', 'message' => 'Data berhasil disimpan.']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Kesalahan saat menyimpan data: ' . $conn->error]);
}

$conn->close();
